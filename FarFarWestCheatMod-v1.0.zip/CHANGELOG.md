# Changelog

Far Far West 作弊模组（UE4SS Lua）。版本号按发布顺序。

## v1.0 — 2026-10-31

首个可发布版本。

### 功能

- `F1` 无敌（`BP_PlayerState_C.invincible`，并持续补满血量/护盾）
- `F2` 无限弹药（`F_RefillAllAmmo_OwningClient`）
- `F3` 无限跳跃 / 冲刺（`jumpsLeft` / `currentDashLeft` / `maxDash`）
- `F4` 加速（`buffMoveSpeed +1.0`）
- `F5` 低重力（`buffGravity -0.65`）
- `F6` / `F7` / `F8` 加金币 / 灵魂 / 铀矿
- `F9` / `Insert` 回满血与护盾
- `F10` 秒杀附近敌人（`BP_Enemy_C.F_DestroyEnemy`）
- `F11` 地图全开
- `F12` 自由视角（游戏自带 `BP_Freecam_C`）
- `Delete` 补满弹药
- 控制台 `ffw` 命令：`god / ammo / jump / speed / gravity / freecam / menu / gold / souls / uranium / heal / kill / reveal / fix / calls / zh / status / diag`

### 调试菜单

- `ffw menu` 可以打开游戏自带的 `UI_CheatMenu`（先 `F12` 进 freecam 成功率最高），再敲一次关闭。
- 菜单已**完全汉化**：41 个按钮 + 16 个分区标题，启动时翻译控件模板（日志 `ZH: template labels translated: 57`）。

### 修复

- 控制台命令一直无效：原来只注册了 `RegisterConsoleCommandHandler`（仅 viewport 上下文），改为优先 `RegisterConsoleCommandGlobalHandler`，并把输出同时写进控制台。
- 关闭菜单后人物无法移动：关闭改为走 `BP_Manager_Menu_C.F_CloseCheat()` 并恢复输入模式（`SetIgnoreMoveInput` / `SetIgnoreLookInput` / `SetPause` / 鼠标指针）。新增 `ffw fix` 兜底。
- 崩溃：移除了导致 `UE4SS.dll` 内部 `ACCESS_VIOLATION` 的"引擎飞行"实验代码（`SetMovementMode` + 40 ms 重压循环）。

### 已知限制

- 官方调试菜单的宿主 `BP_Manager_Cheats_C` 不常驻关卡，必须靠 `ffw menu` 的三条零参入口拉起。
- 血量、金币是服务器权威数值，作为客机加入他人房间会被同步回去；建议单人 / 自己当房主使用。
- 菜单里 `Reset save file` / `Max lvl save` / `Unlock all ...` 会写存档，使用前请备份
  `%LOCALAPPDATA%\FarFarWest\Saved\SaveGames\`。
